from getCaptchaId import getCaptchaId
from test import finalSubmissionRequest
import requests
from bs4 import BeautifulSoup
from urllib3.exceptions import InsecureRequestWarning
import pytesseract
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

# root_url = 'https://freesearchigrservice.maharashtra.gov.in/'

cookies = {
        'ASP.NET_SessionId': 'App2~3frbx3hprevdp2r1qpyilwvh',
    }

headers = {
    'Connection': 'keep-alive',
    'sec-ch-ua': '" Not;A Brand";v="99", "Microsoft Edge";v="91", "Chromium";v="91"',
    'Cache-Control': 'no-cache',
    'X-Requested-With': 'XMLHttpRequest',
    'X-MicrosoftAjax': 'Delta=true',
    'sec-ch-ua-mobile': '?0',
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.59',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Accept': '*/*',
    'Origin': 'https://freesearchigrservice.maharashtra.gov.in',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://freesearchigrservice.maharashtra.gov.in/',
    'Accept-Language': 'en-IN,en;q=0.9,hi;q=0.8,en-US;q=0.7',
}

# Get options
# getOptions = soup.find_all(id='ddldistrictfordoc')
# captchaUrl = soup.find_all(id="imgCaptcha1")[0]["src"]

# responseForId = getCaptchaId()
# soup1 = BeautifulSoup(responseForId.text, "html.parser")
# viewstate = soup1.select('#__VIEWSTATE')[0]['value']
# eventvalidation = soup1.select('#__EVENTVALIDATION')[0]['value']


# captchaQuery = soup1.find_all(id="imgCaptcha1")[0]['src']

def hope():

    # Suppress only the single warning from urllib3 needed.

    # captchaUrl = f'''{root_url}{captchaQuery}'''
    captchaUrl = 'https://freesearchigrservice.maharashtra.gov.in/Handler.ashx?txt=d6c923'
    response = requests.get(captchaUrl, headers=headers, cookies=cookies, verify=False)

    with open("test.png", "wb") as f:
        f.write(response.content)

    captchaText = pytesseract.image_to_string(
        r"/Users/mrgawde/Documents/Projects/ScrappyTest/test.png"
    )

    # print(captchaText)

    responseFromSubmission = finalSubmissionRequest(
        rblDocType=3,
        ddldistrictfordoc=1,
        ddlSROName=1,
        ddlYearForDoc=2021,
        txtDocumentNo=1,
        TextBox1=captchaText[0:6],
        # viewstate=viewstate,
        # eventvalidation=eventvalidation
    )
    print("failed", responseFromSubmission.content)
    soup = BeautifulSoup(responseFromSubmission.text, "html.parser")
    resultTable = soup.find_all(id="RegistrationGrid")
    # if(len(resultTable)==0):
        # hope()
    
    # print(resultTable)
hope()
    



